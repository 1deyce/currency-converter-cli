# Security Policy

## Reporting a Vulnerability

Please email [vt100@charm.sh](mailto:vt100@charm.sh) for any possible security vulnerabilities.
