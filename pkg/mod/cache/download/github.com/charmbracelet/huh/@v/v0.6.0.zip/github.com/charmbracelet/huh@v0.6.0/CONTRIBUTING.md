Contributions are welcome!

Please submit a PR or open an issue to discuss features.
